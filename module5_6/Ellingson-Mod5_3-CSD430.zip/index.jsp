<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.Statement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@page import="java.sql.DriverManager"%>
<!DOCTYPE html>
<!--
CSD430: Server Side Development
Module 5 & 6: CRUD
  Assignment 3: Project Part 1
Isaac Ellingson
7/5/2026

Using our SQL database from Assignment 2, we will now connect to the database
and user account we made. If there is no form data, we perform a small query
to get all the book titles, and allow the user to select one for retrieval.
If there is form data, the user has selected a book for retrieval and we will
display it in a one-row table with a nice header and things.
-->
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="app.css">
</head>
<body>
<%
if (request.getParameter("submit") != null) {
	
	// PROCESS FORM AND DISPLAY BOOK DETAILS
	%>
	<h1>Your Selected Book:</h1>
	<section>
	<%
	
	String isbn13 = request.getParameter("book");
	try (
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/CSD430", "student1", "pass");
			PreparedStatement statement = conn.prepareStatement("SELECT AuthorLastName, AuthorOtherNames, Title, InitialPublicationYear, ISBN13 FROM isaacbooks WHERE ISBN13 = ?;");
		) {
			statement.setString(1, isbn13);
			ResultSet results = statement.executeQuery();
			if (results.next()) {
				String authorLastName = results.getString(1);
				String authorOtherNames = results.getString(2);
				String title = results.getString(3);
				int initialPublicationYear = results.getInt(4);
				long isbn13Long = results.getLong(5);
				
				%>
				<table>
				<thead><tr>
				<td>Last Name</td><td>Other Names</td><td>Title</td><td>Publication Year</td><td>ISBN-13</td>
				</tr></thead>
				<tr>
					<td><%= authorLastName %></td>
					<td><%= authorOtherNames %></td>
					<td><%= title %></td>
					<td><%= initialPublicationYear %></td>
					<td><%= isbn13Long %></td>
				</tr>
				</table>
				
				<%
			} else {
				// TODO: Normally we'd do a redicrect to a custom 404 page for this.
				// but that's out of scope for this little exercise.
				%>
				<p>Could not find the selected book.
				<%
			}
	}
	
%>
	</section>
<%
} else {
%>
<!-- PRESENT FORM -->
<section>
<form method="post" action="index.jsp">
	<label for="book">Please select a book to inspect:</label>
	<select name="book" id="book">
	<%
	// Because I'm not allowed to instrument this properly, we may be missing mysql-connector-j on the classpath. In this case,
	// enrich the stack trace with a suggestion for how to fix the problem.
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (Throwable t) {
		throw new RuntimeException("Please make sure you have mysql-connector-j in your Tomcat instance's 'libs' folder!", t);
	}
	
	try (
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/CSD430", "student1", "pass");
		Statement statement = conn.createStatement();
		ResultSet results = statement.executeQuery("SELECT Title, ISBN13 FROM `isaacbooks`;");
	) {
		while(results.next()) {
			%>
			<option value="<%=results.getString(2)%>">
				<%=results.getString(1)%>
			</option>
			<%
		}
	}
	%>
	</select>
	<input type="submit" name="submit" value="Get Details">
</form>
</section>
<%
}
%>
</body>
</html>