<%@page import="java.util.Optional"%>
<%@page import="module7_2.Book"%>
<%@page import="module7_2.LibraryDatabase"%>
<%@page import="module7_2.BookReference"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<jsp:useBean id="library" class="module7_2.LibraryDatabase"></jsp:useBean>
<!--
CSD430: Server Side Development
Module 5 & 6: CRUD
  Assignment 3: Project Part 1
Isaac Ellingson
7/5/2026

Using our SQL database from Assignment 2, we will now connect to the database
and user account we made. If there is no form data, we perform a small query
to get all the book titles, and allow the user to select one for retrieval.
If there is form data, the user has selected a book for retrieval and we will
display it in a one-row table with a nice header and things.
-->
<html>
<head>
<meta charset="UTF-8">
<title>CSD430 CRUD Assignment: Read Operations</title>
<link rel="stylesheet" href="app.css">
</head>
<body>

<%
if (request.getParameter("book") != null) {
	
	// PROCESS FORM AND DISPLAY BOOK DETAILS
	%>
	<section>
	<h1>CSD430 CRUD Assignment: Read Operations</h1>
	<h2>Your Selected Book:</h2>
	<%
	
	long isbn13 = Long.parseLong(request.getParameter("book"));
	Optional<Book> maybeBook = library.findBook(isbn13);
	if (maybeBook.isPresent()) {
		Book book = maybeBook.get();
		%>
		
		<table>
		<thead><tr>
		<td>Last Name</td><td>Other Names</td><td>Title</td><td>Publication Year</td><td>ISBN-13</td>
		</tr></thead>
		<tr>
			<td><%= book.authorLastName() %></td>
			<td><%= book.authorOtherNames() %></td>
			<td><%= book.title() %></td>
			<td><%= book.publicationYear() %></td>
			<td><%= book.isbn13() %></td>
		</tr>
		</table>
		
		<%
	} else {
		// TODO: Normally we'd do a redicrect to a custom 404 page for this.
		// but that's out of scope for this little exercise.
		%>
		<p>Could not find the selected book.
		<%
	}
	
%>
	</section>
<%
} else {
	// PRESENT FORM
%>
<section>
<h1>CSD430 CRUD Assignment: Read Operations</h1>
<form method="post" action="read.jsp">
	<label for="book">Please select a book to inspect:</label>
	<select name="book" id="book">
	<%
	for(BookReference ref : library.findAllBooks()) {
	%>
		<option value="<%=ref.isbn13()%>">
				<%=ref.title()%>
		</option>
	<%
	}
	%>
	</select>
	<input type="submit" name="submit" value="Get Details">
</form>
</section>
<%
}
%>
</body>
</html>