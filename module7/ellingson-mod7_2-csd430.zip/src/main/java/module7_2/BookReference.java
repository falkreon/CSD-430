package module7_2;

/**
 * Represents a compact reference to a book, giving just the human-readable title and machine-readable isbn13.
 * This is typically used to present book titles to the user for them to select from.
 */
public record BookReference(String title, long isbn13) {
}
