package module7_2;

/**
 * Represents a book in the "isaacbooks" table of the CSD430 database
 */
public record Book(String authorLastName, String authorOtherNames, String title, int publicationYear, long isbn13) {
}
