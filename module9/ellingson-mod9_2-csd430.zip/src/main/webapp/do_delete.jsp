<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<jsp:useBean id="library" class="module7_2.LibraryDatabase"></jsp:useBean>
<!DOCTYPE html>
<!--
CSD430: Server Side Development
Module 9: CRUD
  Assignment 2: Project Part 4
Isaac Ellingson
7/18/2026

Main assignment notes are in delete.jsp
-->
<html>
<head>
<meta charset="UTF-8">
<title>CSD430 CRUD Assignment: Delete Operations</title>
</head>
<body>
<section>
	<h1>CSD430 CRUD Assignment: Delete Operations</h1>
<%
if (request.getParameter("book") != null) {
	try {
		long isbn13 = Long.parseLong(request.getParameter("book"));
		library.removeBook(isbn13);
		
		String dest = (request.getParameter("bonus") != null) ? "bonus.jsp" : "delete.jsp";
		%>
		<p>Book deleted successfully. Please wait while you are redirected...
		<script>
		location.href = "<%= dest %>";
		</script>
		<%
	} catch (NumberFormatException ex) {
		// This is an *actual* error condition, so give the user time to process the result, and let them easily return to the form to retry.
	%>
		<p>An error occurred deleting this book. Please go back and try again.
		<p><a href="delete.jsp">Go Back</a>
	<%
	}
} else {
// The user either arrived at this page in error, or was intentionally trying to break things. Either way, quietly
// redirect them back to the update page
%>
		<p>Please wait while you are redirected...
		<script>
		location.href = "delete.jsp";
		</script>
<%
}
%>


</section>
</body>
</html>