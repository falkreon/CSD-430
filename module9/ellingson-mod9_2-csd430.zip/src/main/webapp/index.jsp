<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>

<html>
<head>
<title>CSD430 CRUD Assignment: Index</title>
</head>
<section>
<h1>CSD430 CRUD Assignment</h1>
<p><a href="create.jsp">Create Operations (Module 7)</a>
<p><a href="read.jsp">Read Operations (Module 5 &amp; 6)</a>
<p><a href="update.jsp">Update Operations (Module 8)</a>
<p><a href="delete.jsp">Delete Operations(Module 9)</a>
<p><a href="bonus.jsp">Bonus Page: Fused create, read, update, and delete</a>
</section>
</html>