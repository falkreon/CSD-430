<%@page import="java.util.List"%>
<%@page import="module7_2.Book"%>
<%@page import="module7_2.LibraryDatabase"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<!--
CSD430: Server Side Development
Module 9: CRUD
  Assignment 2: Project Part 4
Isaac Ellingson
7/18/2026

The final part of the CRUD assignment is... badly designed. If we're displaying a table
of records, we can just put individual delete links next to each record. We don't have
to deal with this dropdown garbage.

But the assignment is to display a table with ALL records in the database, then a dropdown
for which book to delete, and a button to delete that book. That's all.

This page emits the list of all books and the dropdown. The next page (do_delete.jsp)
performs the actual delete.
-->
<jsp:useBean id="library" class="module7_2.LibraryDatabase"></jsp:useBean>
<html>
<head>
<meta charset="UTF-8">
<title>CSD430 CRUD Assignment: Delete Operations</title>
<link rel="stylesheet" href="app.css">
</head>
<body>
<section>
	<h1>CSD430 CRUD Assignment: Delete Operations</h1>
	
	<%
	// Since we need this data for both the table and the dropdown, we're going to call it once and reuse it.
	List<Book> allBooks = library.getAllBooks();
	%>
	
	<h2>All Books Currently In This Database:</h2>
	<table>
	<thead><tr>
	<td>Last Name</td><td>Other Names</td><td>Title</td><td>Publication Year</td><td>ISBN-13</td>
	</tr></thead>
	<%
	for(Book book : allBooks) {
	%>
	<tr>
		<td><%= book.authorLastName() %></td>
		<td><%= book.authorOtherNames() %></td>
		<td><%= book.title() %></td>
		<td><%= book.publicationYear() %></td>
		<td><%= book.isbn13() %></td>
	</tr>
	<%
	}
	%>
	</table>
	
	<form class="fullwidth" method="post" action="do_delete.jsp">
	
	<% if (allBooks.isEmpty()) { %>
		<p>There are no books to delete.
	
	<% } else { %>
	
	<p><label for="book">Please select a book to DELETE:</label>
	<p><em>There will be no confirmation. The book will be deleted immediately!</em>
	<p><select name="book" id="book">
	<%
	for(Book book : allBooks) {
	%>
		<option value="<%=book.isbn13()%>">
				<%=book.title()%>
		</option>
	<%
	}
	%>
	</select>
	<p><input type="submit" name="submit" class="warning-btn" value="Delete this book forever (A long time!)">
	<% } %>
	</form>
	
	<p><a href="index.jsp">Back to Index</a>
</section>
</body>
</html>