<%@page import="java.util.List"%>
<%@page import="module7_2.Book"%>
<%@page import="module7_2.LibraryDatabase"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<!--
CSD430: Server Side Development
Module 9: CRUD
  Assignment 2: Project Part 4
Isaac Ellingson
7/18/2026

This bonus page is what I'd do if I knew we were listing out all the books from the start - we can
EASILY fit all of the CRUD operations right on the same page.

One slight implementation detail: When commands are issued from the "bonus" page, a parameter
"bonus=1" is fed to all the pages in the processing chain to let them know to redirect back to
this bonus page instead of their original targets. That keeps us in a tight read/edit loop the
user's going to like a lot more than how this project was designed.
-->
<jsp:useBean id="library" class="module7_2.LibraryDatabase"></jsp:useBean>
<html>
<head>
<meta charset="UTF-8">
<title>CSD430 CRUD Assignment: Bonus Page</title>
<link rel="stylesheet" href="app.css">
</head>
<body>
<section>
	<h1>CSD430 CRUD Assignment: Bonus Page</h1>
	
	<p>All CRUD operations are available simultaneously from this page. Please note that there is no confirmation
	on the Delete buttons.
	
	<%
	// Since we need this data for both the table and the dropdown, we're going to call it once and reuse it.
	List<Book> allBooks = library.getAllBooks();
	%>
	
	<h2>All Books Currently In This Database:</h2>
	<table>
	<thead><tr>
	<td>Last Name</td><td>Other Names</td><td>Title</td><td>Publication Year</td><td>ISBN-13</td><td>Actions</td>
	</tr></thead>
	<%
	for(Book book : allBooks) {
	%>
	<tr>
		<td><%= book.authorLastName() %></td>
		<td><%= book.authorOtherNames() %></td>
		<td><%= book.title() %></td>
		<td><%= book.publicationYear() %></td>
		<td><%= book.isbn13() %></td>
		<td><a href="update.jsp?bonus=1&book=<%= book.isbn13() %>">Edit</a> &nbsp;&nbsp; <a href="do_delete.jsp?bonus=1&book=<%= book.isbn13() %>">Delete</a></td>
	</tr>
	<%
	}
	%>
	</table>
	
	<p><a class="add-btn" href="create.jsp?bonus=1">+</a>
	
	<p><a href="index.jsp">Back to Index</a>
</section>
</body>
</html>