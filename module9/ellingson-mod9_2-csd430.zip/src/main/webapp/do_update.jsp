<%@page import="java.util.Optional"%>
<%@page import="module7_2.Book"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<jsp:useBean id="library" class="module7_2.LibraryDatabase"></jsp:useBean>
<!DOCTYPE html>
<!--
CSD430: Server Side Development
Module 8: CRUD
  Assignment 2: Project Part 3
Isaac Ellingson
7/17/2026

This is one parts of a four-page flow:
  1. A dropdown list of books to edit, and an edit button (update.jsp)
  2. A web form with the book's existing data in (mostly) editable fields (update.jsp)
  3. A serverside script that processes the update (this page)
  4. A display of the updated book data (read.jsp)
  
Main assignment notes are in update.jsp
-->
<html>
<head>
<meta charset="UTF-8">
<title>CSD430 CRUD Assignment: Update Operations</title>
</head>
<body>

<section>
	<h1>CSD430 CRUD Assignment: Update Operations</h1>
<%
if (request.getParameter("isbn13") != null) {
	/* My first draft of this bit of code used Optional.ifPresentOrElse(), but it appears that
	 * JSP delimiters don't play nice with lambdas. I'm starting to see the Java EE system
	 * age pretty unacceptably now. If you can't handle lambdas, you're in *trouble*!
	 *
	 * Even as written, the last "/script" tag inspects as unmatched, even though it is.
	 */
	
	Optional<Book> maybeBook = Book.fromForm(request);
	if (maybeBook.isPresent() && library.updateBook(maybeBook.get())) {
		String dest = (request.getParameter("bonus") != null) ? "bonus.jsp" : "read.jsp?book=" + maybeBook.get().isbn13();
	%>
		<p>Update successful. Please wait while you are redirected...
		<script>
		location.href = "<%= dest %>";
		</script>
	<%
	} else {
		// This is an *actual* error condition, so give the user time to process the result, and let them easily return to the form to retry.
	%>
		<p>An error occurred editing this book. Please go back and try again.
		<p><a href="update.jsp">Go Back</a>
	<%
	}
	
} else {
// The user either arrived at this page in error, or was intentionally trying to break things. Either way, quietly
// redirect them back to the update page
%>
	<p>Please wait while you are redirected...
	<script>
	location.href = "update.jsp";
	</script>
<%
}
%>
</section>

</body>
</html>