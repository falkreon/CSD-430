package module7_2;

import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;


/**
 * Represents a book in the "isaacbooks" table of the CSD430 database
 */
public record Book(String authorLastName, String authorOtherNames, String title, int publicationYear, long isbn13) {
	
	public static Optional<Book> fromForm(HttpServletRequest request) {
		String authorLastName = request.getParameter("authorLastName");
		if (authorLastName == null || authorLastName.isBlank()) return Optional.empty();
		String authorOtherNames = request.getParameter("authorOtherNames");
		if (authorOtherNames == null || authorOtherNames.isBlank()) return Optional.empty();
		String bookTitle = request.getParameter("title");
		if (bookTitle == null || bookTitle.isBlank()) return Optional.empty();
		int publicationYear = 0;
		try {
			publicationYear = Integer.parseInt(request.getParameter("publicationYear"));
		} catch (NumberFormatException ex) {
			return Optional.empty();
		}
		long isbn13 = 0L;
		try {
			isbn13 = Long.parseLong(request.getParameter("isbn13"));
		} catch (NumberFormatException ex) {
			return Optional.empty();
		}
		
		return Optional.of(new Book(authorLastName, authorOtherNames, bookTitle, publicationYear, isbn13));
	}
}
