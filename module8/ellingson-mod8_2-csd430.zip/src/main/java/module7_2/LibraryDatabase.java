package module7_2;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.ejb.Stateless;

/**
 * Stateless bean to represent the Library database to the application in an idiomatic Java way.
 */

/* Not a singleton "bean" because those require external orchestration. I'm not certain we can reproduce that on your
 * device without including a Config class or some additional XML, both of which sound especially fragile.
 * 
 * But it's worth saying, we don't really get the dependency injection from it being this kind of bean.
 * 
 * Note: The Serializable interface is here for assignment compliance; it would actually be better for the
 * server to throw an error immediately on usage of ObjectOutputStream/ObjectInputStream, because these
 * represent a high-severity vulnerability with *many* CVEs across Java's history.
 */
@Stateless
public class LibraryDatabase implements Serializable {
	private static final long serialVersionUID = -5804697114813936651L;

	private Connection createConnection() throws SQLException {
		return DriverManager.getConnection("jdbc:mysql://localhost/CSD430", "student1", "pass");
	}
    
    /**
     * Adds the specified book to the library.
     * @param book The book to add
     * @return True if the book was added successfully, otherwise false.
     */
    public boolean addBook(Book book) {
    	try (
    			Connection connection = createConnection();
    			PreparedStatement stmt = connection.prepareStatement(
    			"INSERT INTO isaacbooks (AuthorLastName, AuthorOtherNames, Title, InitialPublicationYear, ISBN13) VALUES (?, ?, ?, ?, ?);"
    		)) {
    		stmt.setString(1, book.authorLastName());
    		stmt.setString(2, book.authorOtherNames());
    		stmt.setString(3, book.title());
    		stmt.setInt(4, book.publicationYear());
    		// We cannot auto-assign / auto-increment the primary key as requested because it's an externally-assigned ISBN-13.
    		stmt.setLong(5, book.isbn13());
    		stmt.execute();
    		
    		return true;
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    		return false;
    	}
    }
    
    /**
	 * Find a book by its ISBN-13 number.
	 * @param isbn13 The ISBN-13 number of the desired book
	 * @return An Optional containing the book if it was found and retrieved successfully. If there was an error or the book was not found, empty is returned.
	 */
    public Optional<Book> findBook(long isbn13) {
    	try (
    			Connection connection = createConnection();
    			PreparedStatement stmt = connection.prepareStatement(
    			"SELECT AuthorLastName, AuthorOtherNames, Title, InitialPublicationYear, ISBN13 FROM isaacbooks WHERE ISBN13 = ?;"
    		)) {
    		stmt.setLong(1, isbn13);
    		try (ResultSet results = stmt.executeQuery()) {
    			results.next();
    			return Optional.of(new Book(
    					results.getString(1),
    					results.getString(2),
    					results.getString(3),
    					results.getInt(4),
    					results.getLong(5)
    					));
    		}
    		
    	} catch (SQLException ex) {
    		return Optional.empty();
		}
    }
    
    /**
     * Gets a list of BookReferences for all books in the library. Not suitable for being called in large libraries!
     * @return A complete list of books in the library.
     */
    public List<BookReference> findAllBooks() {
    	List<BookReference> results = new ArrayList<>();
    	try (
    			Connection connection = createConnection();
    			Statement stmt = connection.createStatement();
    			ResultSet resultSet = stmt.executeQuery("SELECT Title, ISBN13 FROM isaacbooks;")
    		) {
    		
    		while(resultSet.next()) {
    			BookReference ref = new BookReference(resultSet.getString(1), resultSet.getLong(2));
    			results.add(ref);
    		}
    	} catch (SQLException ex) {
    		ex.printStackTrace(); // Fail gracefully, make a fuss about it, and return an empty list.
    	}
    	
    	return results;
    }
    
    /**
     * Takes an existing book in the library with an identical ISBN-13, and updates its details to match the provided Book.
     * @param book The updated data for the Book in question
     * @return True if the book was successfully updated. False if the book was unable to be updated for any reason.
     */
    public boolean updateBook(Book book) {
    	try (
    			Connection connection = createConnection();
    			PreparedStatement stmt = connection.prepareStatement(
    			"UPDATE isaacbooks SET AuthorLastName = ?, AuthorOtherNames = ?, Title = ?, InitialPublicationYear = ? WHERE ISBN13 = ?;"
    		)) {
    		stmt.setString(1, book.authorLastName());
    		stmt.setString(2, book.authorOtherNames());
    		stmt.setString(3, book.title());
    		stmt.setInt(4, book.publicationYear());
    		stmt.setLong(5, book.isbn13());
    		stmt.execute();
    		
    		return true;
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    		return false;
    	}
    }
    
    /**
     * Removes the specified book from the library.
     * @param isbn13 The isbn-13 of a book in the library to remove
     * @return True if the book was successfully removed. False if the book was unable to be removed for any reason.
     */
    public boolean removeBook(long isbn13) {
    	try (
    			Connection connection = createConnection();
    			PreparedStatement stmt = connection.prepareStatement(
    			"DELETE FROM isaacbooks WHERE ISBN13 = ?;"
    		)) {
    		stmt.setLong(1, isbn13);
    		stmt.execute();
    		
    		return true;
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    		return false;
    	}
    }
    
    /**
     * Removes a Book from the library. The details will not be compared - any book with a matching ISBN-13 will be removed.
     * @param book The book to remove
     * @return True if the book was successfully removed. False if the book was unable to be removed for any reason.
     */
    public boolean removeBook(Book book) {
    	return removeBook(book.isbn13());
    }
    
}
