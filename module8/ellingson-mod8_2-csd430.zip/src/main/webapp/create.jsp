<%@page import="module7_2.Book"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<!--
CSD430: Server Side Development
Module 7: CRUD
  Assignment 2: Project Part 2
Isaac Ellingson
7/12/2026

If there is no query, displays the create-book entry form. If the book form has been filled out and sent,
a new book is created, and the user is redirected to the read form for their new book with a URL
query parameter. HTML5 pattern validation is used on form fields, but additional checks are made
serverside.
-->
<html>
<head>
<meta charset="UTF-8">
<title>CSD430 CRUD Assignment: Create Operations</title>
<link rel="stylesheet" href="app.css">
</head>
<body>
<section>
<h1>CSD430 CRUD Assignment: Create Operations</h1>
<%
if (request.getParameter("isbn13") != null) {
	
	boolean valid = true;
	
	String authorLastName = request.getParameter("authorLastName");
	if (authorLastName == null || authorLastName.isBlank()) valid = false;
	String authorOtherNames = request.getParameter("authorOtherNames");
	if (authorOtherNames == null || authorOtherNames.isBlank()) valid = false;
	String bookTitle = request.getParameter("title");
	if (bookTitle == null || bookTitle.isBlank()) valid = false;
	int publicationYear = 0;
	try {
		publicationYear = Integer.parseInt(request.getParameter("publicationYear"));
	} catch (NumberFormatException ex) {
		valid = false;
	}
	long isbn13 = 0L;
	try {
		isbn13 = Long.parseLong(request.getParameter("isbn13"));
	} catch (NumberFormatException ex) {
		valid = false;
	}
	
	if (!valid) {
		%>
		<p>An error has occurred processing the data to create your book. Please check your data and try again.
		<p><a href="create.jsp">Retry</a>
		<%
	} else {
	
		%>
		<jsp:useBean id="library" class="module7_2.LibraryDatabase" />
		<%
		Book book = new Book(authorLastName, authorOtherNames, bookTitle, publicationYear, isbn13);
		if (library.addBook(book)) {
			%>
			<p>Your book has been added successfully. Redirecting you to your book.
			<script>
			location.href = "read.jsp?book=<%= book.isbn13() %>";
			</script>
			<%
		} else {
			%>
			<p>An unknown error occurred creating your book. Please check to make sure it's not already in the database.
			<p><a href="create.jsp">Retry</a>
			<%
		}
	}
} else {
%>
	<form method="post" action="create.jsp" class="table-form">
		<label for="authorLastName">Author Last Name</label>
		<input id="book-authorLastName" name="authorLastName" type="text" required>
		
		<label for="authorOtherNames">Author Other names</label>
		<input id="book-authorOtherNames" name="authorOtherNames" type="text" required>
		
		<label for="title">Book Title</label>
		<input id="book-title" name="title" type="text" required>
		
		<label for="publicationYear">Publication Year</label>
		<input id="book-publicationYear" name="publicationYear" type="text" pattern="[0-9]{4}" required>
		
		<label for="isbn13">ISBN-13</label>
		<input id="isbn13" name="isbn13" type="text" pattern="[0-9]{3}-?[0-9]-?[0-9]{4}-?[0-9]{4}-?[0-9]" required>
		
		<input class="colspan" type="submit" name="submit" value="Create Book">
	</form>
	
	<p><a href="index.jsp">Back to Index</a>
<%
}
%>

</section>
</body>
</html>