<%@page import="java.util.Optional"%>
<%@page import="module7_2.Book"%>
<%@page import="module7_2.BookReference"%>
<%@page import="module7_2.LibraryDatabase"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<jsp:useBean id="library" class="module7_2.LibraryDatabase"></jsp:useBean>
<!--
CSD430: Server Side Development
Module 8: CRUD
  Assignment 2: Project Part 3
Isaac Ellingson
7/17/2026

This is two parts of a four-page flow:
  1. A dropdown list of books to edit, and an edit button (this page)
  2. A web form with the book's existing data in (mostly) editable fields (this page)
  3. A serverside script that processes the update (do_update.jsp)
  4. A display of the updated book data (read.jsp)

Most of the backend logic for this assignment was already written as part of the LibraryDatabase bean,
and just bugfixed this week.

This week I'm just about running up against the complexity limit for Java EE. Eclipse is already
struggling to match up servlet tags, script tags, etc.. Which is a bad sign, because enterprise
applications tend to deal with *more* complexity than their consumer counterparts. To deal with this,
in production maybe I'd avoid "doubling up" the forms with the form processing like I'm doing here.

I'm also not feeling like the promised encapsulation or separation between code and presentation are
really materializing here. I wasn't planning on returning to tomcat/glassfish before this assignment,
and I'm especially not planning to after this. I'd actually rather write php.
-->
<html>
<head>
<meta charset="UTF-8">
<title>CSD430 CRUD Assignment: Create Operations</title>
<link rel="stylesheet" href="app.css">
</head>
<body>
<section>
<h1>CSD430 CRUD Assignment: Update Operations</h1>
<%
Book book = null;

if (request.getParameter("book") != null) {
	try {
		long isbn13 = Long.parseLong(request.getParameter("book"));
		Optional<Book> maybeBook = library.findBook(isbn13);
		if (maybeBook.isPresent()) book = maybeBook.get();
	} catch (NumberFormatException ex) {}
	
	if (book != null) {
%>
	<form method="post" action="do_update.jsp" class="table-form">
		<label for="authorLastName">Author Last Name</label>
		<input id="book-authorLastName" name="authorLastName" type="text" value="<%= book.authorLastName() %>" required>
		
		<label for="authorOtherNames">Author Other names</label>
		<input id="book-authorOtherNames" name="authorOtherNames" type="text" value="<%= book.authorOtherNames() %>"required>
		
		<label for="title">Book Title</label>
		<input id="book-title" name="title" type="text" value="<%= book.title() %>"required>
		
		<label for="publicationYear">Publication Year</label>
		<input id="book-publicationYear" name="publicationYear" type="text" pattern="[0-9]{4}" value="<%= book.publicationYear() %>"required>
		
		<label for="isbn13">ISBN-13</label>
		<input id="isbn13" name="isbn13" type="text" value="<%= book.isbn13() %>" required readonly="readonly">
		
		<input class="colspan" type="submit" name="submit" value="Update Book">
	</form>
<%	
		
	} else {
%>
	<p>An error occurred retrieving that book for editing. Are you sure that book exists?
	<p><a href="update.jsp">Go Back</a>
<%		
	}
} else {
%>
<form method="post" action="update.jsp">
	<label for="book">Please select a book to edit:</label>
	<select name="book" id="book">
	<%
	for(BookReference ref : library.findAllBooks()) {
	%>
		<option value="<%=ref.isbn13()%>">
				<%=ref.title()%>
		</option>
	<%
	}
	%>
	</select>
	<input type="submit" name="submit" value="Edit">
</form>
<%
}
%>
<p><a href="index.jsp">Back to Index</a>
</section>
</body>
</html>